package com.home.calsi;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;

public class Age extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    TextView todaydate;
    TextView todaymonth;
    TextView todayyear;
    TextView birthdate;
    TextView birthmonth;
    TextView birthyear;

    TextView ansdate;
    TextView ansmonth;
    TextView ansyear;
    TextView nextdate;
    TextView nextmonth;
    TextView nextyear;
    DatePickerDialog.OnDateSetListener setListener;
    int toyear;
    int tomonth;
    int todate;
    int biyear = 0;
    int bimonth = 0;
    int bidate = 0;


    public void todays(View view) {
        DatePickerDialog datePickerDialog = new DatePickerDialog(Age.this, android.R.style.Theme_Holo_Dialog_MinWidth, setListener, toyear, tomonth, todate);
        datePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        datePickerDialog.show();
    }

    public void birth(View view) {
        DatePickerDialog datePickerDialog = new DatePickerDialog(Age.this, android.R.style.Theme_Holo_Dialog_MinWidth, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                bidate = i2;
                bimonth = i1 + 1;
                biyear = i;
                birthdate.setText(String.valueOf(bidate));
                birthmonth.setText(String.valueOf(bimonth));
                birthyear.setText(String.valueOf(biyear));
            }
        }, toyear, tomonth, todate);
        datePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        datePickerDialog.show();
    }


    public void calculate(View view) {
        if (bidate == 0 || bimonth == 0 || biyear == 0) {
            Toast.makeText(this, "enter value", Toast.LENGTH_SHORT).show();
        } else {
            long totaltodays = toyear * 365 + tomonth * 30 + todate;
            long totalbidays = biyear * 365 + bimonth * 30 + todate;
            int birthdaydate = (int) (totaltodays - totalbidays);
            int birthdayyear = (int) birthdaydate / 365;
            birthdaydate = birthdaydate - birthdayyear * 365;
            int birthdaymonth = (int) birthdaydate / 30;
            birthdaydate = birthdaydate - birthdaymonth * 30;

            ansdate.setText(String.valueOf(birthdaydate));
            ansmonth.setText(String.valueOf(birthdaymonth));
            ansyear.setText(String.valueOf(birthdayyear));
            totaltodays = (toyear + 1) * 365 + bimonth * 30 + todate;
            totalbidays = toyear * 365 + tomonth * 30 + todate;
            birthdaydate = (int) (totaltodays - totalbidays);
            birthdayyear = (int) birthdaydate / 365;
            birthdaydate = birthdaydate - birthdayyear * 365;
            birthdaymonth = (int) birthdaydate / 30;
            birthdaydate = birthdaydate - birthdaymonth * 30;

            nextdate.setText(String.valueOf(birthdaydate));
            nextmonth.setText(String.valueOf(birthdaymonth));
            nextyear.setText(String.valueOf(birthdayyear));
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_age);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setCheckedItem(R.id.agecalculate);
        todaydate = findViewById(R.id.todaydate);
        todaymonth = findViewById(R.id.todaymonth);
        todayyear = findViewById(R.id.todayyear);
        birthdate = findViewById(R.id.birthdate);
        birthmonth = findViewById(R.id.birthmonth);
        birthyear = findViewById(R.id.birthyear);
        ansdate = findViewById(R.id.ansday);
        ansmonth = findViewById(R.id.ansmonth);
        ansyear = findViewById(R.id.ansyear);
        nextdate = findViewById(R.id.nextday);
        nextmonth = findViewById(R.id.nextmonth);
        nextyear = findViewById(R.id.nextyear);
        Calendar calender = Calendar.getInstance();
        Date l = new Date(System.currentTimeMillis());
        toyear = 2020;
        tomonth = l.getMonth() + 1;
        todate = l.getDate();
        todaydate.setText(String.valueOf(todate));
        todaymonth.setText(String.valueOf(tomonth));
        todayyear.setText(String.valueOf((toyear)));
        setListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                todate = i2;
                tomonth = i1 + 1;
                toyear = i;
                todaydate.setText(String.valueOf(todate));
                todaymonth.setText(String.valueOf(tomonth));
                todayyear.setText(String.valueOf((toyear)));
            }
        };
    }




    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.Share) {

        }else if (id == R.id.remove) {

        }else if (id == R.id.about) {

        }else if (id == R.id.help) {

        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();


        if (id == R.id.simplecalculate) {
            finish();
        }
        else if (id == R.id.unitcalculate) {
            finish();
            Intent intent=new Intent(getApplicationContext(),UnitConvertor.class);
            startActivity(intent);
        }
        else if (id == R.id.agecalculate) {

        } else if (id == R.id.percentagecalculate) {
            finish();
            Intent intent=new Intent(getApplicationContext(),Percentage.class);
            startActivity(intent);

        } else if (id == R.id.healthcalculate) {
            finish();
            Intent intent=new Intent(getApplicationContext(),HealthCalculator.class);
            startActivity(intent);

        } else if (id == R.id.emicalculate) {
            finish();
            Intent intent=new Intent(getApplicationContext(),EMI.class);
            startActivity(intent);

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.help) {

        }else if(id==R.id.remove_ad){

        }else if(id==R.id.about){

        }


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
